using System.ComponentModel.DataAnnotations;

namespace MovieCatalogApi.Models;

public class Director
{
    public int Id { get; set; }

    [Required]
    [MaxLength(120)]
    public string Name { get; set; } = string.Empty;

    [MaxLength(80)]
    public string? Country { get; set; }

    // Navigation
    public List<Movie> Movies { get; set; } = new();
}
