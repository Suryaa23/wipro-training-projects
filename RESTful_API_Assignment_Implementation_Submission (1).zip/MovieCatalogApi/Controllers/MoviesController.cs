using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MovieCatalogApi.Data;
using MovieCatalogApi.Dtos;
using MovieCatalogApi.Models;

namespace MovieCatalogApi.Controllers;

[ApiController]
[Route("api/movies")]
public class MoviesController : ControllerBase
{
    private readonly AppDbContext _db;

    public MoviesController(AppDbContext db) => _db = db;

    // GET: api/movies
    [HttpGet]
    public async Task<ActionResult<IEnumerable<MovieReadDto>>> GetAll()
    {
        var items = await _db.Movies
            .AsNoTracking()
            .Include(m => m.Director)
            .OrderBy(m => m.Id)
            .Select(m => new MovieReadDto
            {
                Id = m.Id,
                Title = m.Title,
                ReleaseYear = m.ReleaseYear,
                DirectorId = m.DirectorId,
                DirectorName = m.Director!.Name
            })
            .ToListAsync();

        return Ok(items);
    }

    // GET: api/movies/{id}
    [HttpGet("{id:int}")]
    public async Task<ActionResult<MovieReadDto>> GetById(int id)
    {
        var m = await _db.Movies
            .AsNoTracking()
            .Include(x => x.Director)
            .FirstOrDefaultAsync(x => x.Id == id);

        if (m is null) return NotFound(new { message = $"Movie with id={id} not found." });

        return Ok(new MovieReadDto
        {
            Id = m.Id,
            Title = m.Title,
            ReleaseYear = m.ReleaseYear,
            DirectorId = m.DirectorId,
            DirectorName = m.Director!.Name
        });
    }

    // POST: api/movies
    [HttpPost]
    public async Task<ActionResult<MovieReadDto>> Create(MovieCreateDto dto)
    {
        // Validate director exists
        var director = await _db.Directors.FindAsync(dto.DirectorId);
        if (director is null)
            return NotFound(new { message = $"Director with id={dto.DirectorId} not found." });

        var entity = new Movie
        {
            Title = dto.Title.Trim(),
            ReleaseYear = dto.ReleaseYear,
            DirectorId = dto.DirectorId
        };

        _db.Movies.Add(entity);
        await _db.SaveChangesAsync();

        var read = new MovieReadDto
        {
            Id = entity.Id,
            Title = entity.Title,
            ReleaseYear = entity.ReleaseYear,
            DirectorId = entity.DirectorId,
            DirectorName = director.Name
        };

        return CreatedAtAction(nameof(GetById), new { id = entity.Id }, read);
    }

    // PUT: api/movies/{id}
    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, MovieUpdateDto dto)
    {
        var entity = await _db.Movies.FindAsync(id);
        if (entity is null) return NotFound(new { message = $"Movie with id={id} not found." });

        var director = await _db.Directors.FindAsync(dto.DirectorId);
        if (director is null)
            return NotFound(new { message = $"Director with id={dto.DirectorId} not found." });

        entity.Title = dto.Title.Trim();
        entity.ReleaseYear = dto.ReleaseYear;
        entity.DirectorId = dto.DirectorId;

        await _db.SaveChangesAsync();
        return NoContent(); // 204
    }

    // DELETE: api/movies/{id}
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var entity = await _db.Movies.FindAsync(id);
        if (entity is null) return NotFound(new { message = $"Movie with id={id} not found." });

        _db.Movies.Remove(entity);
        await _db.SaveChangesAsync();
        return NoContent(); // 204
    }
}
