using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MovieCatalogApi.Data;
using MovieCatalogApi.Dtos;
using MovieCatalogApi.Models;

namespace MovieCatalogApi.Controllers;

[ApiController]
[Route("api/directors")]
public class DirectorsController : ControllerBase
{
    private readonly AppDbContext _db;

    public DirectorsController(AppDbContext db) => _db = db;

    // GET: api/directors
    [HttpGet]
    public async Task<ActionResult<IEnumerable<DirectorReadDto>>> GetAll()
    {
        var items = await _db.Directors
            .AsNoTracking()
            .OrderBy(d => d.Id)
            .Select(d => new DirectorReadDto { Id = d.Id, Name = d.Name, Country = d.Country })
            .ToListAsync();

        return Ok(items);
    }

    // GET: api/directors/{id}
    [HttpGet("{id:int}")]
    public async Task<ActionResult<DirectorReadDto>> GetById(int id)
    {
        var d = await _db.Directors.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        if (d is null) return NotFound(new { message = $"Director with id={id} not found." });

        return Ok(new DirectorReadDto { Id = d.Id, Name = d.Name, Country = d.Country });
    }

    // POST: api/directors
    [HttpPost]
    public async Task<ActionResult<DirectorReadDto>> Create(DirectorCreateDto dto)
    {
        var entity = new Director { Name = dto.Name.Trim(), Country = dto.Country?.Trim() };

        _db.Directors.Add(entity);
        await _db.SaveChangesAsync();

        var read = new DirectorReadDto { Id = entity.Id, Name = entity.Name, Country = entity.Country };
        return CreatedAtAction(nameof(GetById), new { id = entity.Id }, read);
    }

    // PUT: api/directors/{id}
    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, DirectorCreateDto dto)
    {
        var entity = await _db.Directors.FindAsync(id);
        if (entity is null) return NotFound(new { message = $"Director with id={id} not found." });

        entity.Name = dto.Name.Trim();
        entity.Country = dto.Country?.Trim();

        await _db.SaveChangesAsync();
        return NoContent();
    }

    // DELETE: api/directors/{id}
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var entity = await _db.Directors.FindAsync(id);
        if (entity is null) return NotFound(new { message = $"Director with id={id} not found." });

        _db.Directors.Remove(entity);
        await _db.SaveChangesAsync();
        return NoContent();
    }

    // GET: api/directors/{directorId}/movies
    [HttpGet("{directorId:int}/movies")]
    public async Task<ActionResult<IEnumerable<MovieReadDto>>> GetMoviesByDirector(int directorId)
    {
        var directorExists = await _db.Directors.AsNoTracking().AnyAsync(d => d.Id == directorId);
        if (!directorExists) return NotFound(new { message = $"Director with id={directorId} not found." });

        var movies = await _db.Movies
            .AsNoTracking()
            .Include(m => m.Director)
            .Where(m => m.DirectorId == directorId)
            .OrderBy(m => m.Id)
            .Select(m => new MovieReadDto
            {
                Id = m.Id,
                Title = m.Title,
                ReleaseYear = m.ReleaseYear,
                DirectorId = m.DirectorId,
                DirectorName = m.Director!.Name
            })
            .ToListAsync();

        return Ok(movies);
    }
}
