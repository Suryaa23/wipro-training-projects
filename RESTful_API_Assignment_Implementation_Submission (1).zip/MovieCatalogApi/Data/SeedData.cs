using MovieCatalogApi.Models;

namespace MovieCatalogApi.Data;

public static class SeedData
{
    public static void Initialize(AppDbContext db)
    {
        if (db.Directors.Any() || db.Movies.Any())
            return;

        var directors = new List<Director>
        {
            new() { Name = "Christopher Nolan", Country = "UK" },
            new() { Name = "Rajkumar Hirani", Country = "India" }
        };

        db.Directors.AddRange(directors);
        db.SaveChanges();

        var movies = new List<Movie>
        {
            new() { Title = "Inception", ReleaseYear = 2010, DirectorId = directors[0].Id },
            new() { Title = "Interstellar", ReleaseYear = 2014, DirectorId = directors[0].Id },
            new() { Title = "3 Idiots", ReleaseYear = 2009, DirectorId = directors[1].Id }
        };

        db.Movies.AddRange(movies);
        db.SaveChanges();
    }
}
