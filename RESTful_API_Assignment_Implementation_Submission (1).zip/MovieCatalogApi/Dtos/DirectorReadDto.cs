namespace MovieCatalogApi.Dtos;

public class DirectorReadDto
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Country { get; set; }
}
