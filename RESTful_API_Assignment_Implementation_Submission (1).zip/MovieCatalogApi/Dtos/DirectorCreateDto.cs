using System.ComponentModel.DataAnnotations;

namespace MovieCatalogApi.Dtos;

public class DirectorCreateDto
{
    [Required]
    [MaxLength(120)]
    public string Name { get; set; } = string.Empty;

    [MaxLength(80)]
    public string? Country { get; set; }
}
