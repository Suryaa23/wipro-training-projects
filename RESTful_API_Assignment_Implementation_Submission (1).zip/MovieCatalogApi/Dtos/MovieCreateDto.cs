using System.ComponentModel.DataAnnotations;

namespace MovieCatalogApi.Dtos;

public class MovieCreateDto
{
    [Required]
    [MaxLength(200)]
    public string Title { get; set; } = string.Empty;

    [Range(1888, 2100)]
    public int ReleaseYear { get; set; }

    [Required]
    public int DirectorId { get; set; }
}
