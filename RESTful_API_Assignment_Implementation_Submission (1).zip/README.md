# RESTful API – Movie Catalog (ASP.NET Core)

This submission implements the RESTful API required in **Problem_Statement_43.pdf**.

## Tech
- ASP.NET Core Web API (Controllers + Attribute Routing)
- EF Core + SQLite (local DB file: `moviecatalog.db`)
- Swagger UI for quick testing

## How to Run (Visual Studio 2022)
1. Open `MovieCatalogApi.sln`
2. Restore NuGet packages (VS will prompt automatically)
3. Run the project
4. Open Swagger: `/swagger`

> Note: On first run the API auto-creates the SQLite database and seeds sample data.

## Base URL
- https://localhost:7061 (HTTPS) or http://localhost:5061 (HTTP)

## Endpoints (as per problem statement)

### Movies
- `GET    /api/movies`
- `GET    /api/movies/{id}`
- `POST   /api/movies`
- `PUT    /api/movies/{id}`
- `DELETE /api/movies/{id}`

### Directors
- `GET    /api/directors`
- `GET    /api/directors/{id}`
- `POST   /api/directors`
- `PUT    /api/directors/{id}`
- `DELETE /api/directors/{id}`

### Association
- `GET /api/directors/{directorId}/movies`

## Postman Sample Bodies

### Create Director (POST /api/directors)
```json
{
  "name": "Mani Ratnam",
  "country": "India"
}
```

### Create Movie (POST /api/movies)
```json
{
  "title": "Roja",
  "releaseYear": 1992,
  "directorId": 1
}
```

### Update Movie (PUT /api/movies/1)
```json
{
  "title": "Inception (Updated)",
  "releaseYear": 2010,
  "directorId": 1
}
```

## Expected Status Codes
- 200 OK (GET)
- 201 Created (POST)
- 204 No Content (PUT, DELETE success)
- 400 Bad Request (validation errors)
- 404 Not Found (missing movie/director)

## Fiddler
Use Fiddler to inspect request/response headers and verify `Content-Type: application/json`.
