// Observer Pattern
using System;
using System.Collections.Generic;

public interface IObserver
{
    void Update(int temperature);
}

public class WeatherStation
{
    private List<IObserver> observers = new List<IObserver>();

    public void Register(IObserver observer) => observers.Add(observer);
    public void Unregister(IObserver observer) => observers.Remove(observer);

    public void Notify(int temperature)
    {
        foreach (var observer in observers)
            observer.Update(temperature);
    }
}