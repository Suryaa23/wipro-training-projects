// Factory Pattern
public interface IDocument
{
    void Create();
}

public class PdfDocument : IDocument
{
    public void Create() => System.Console.WriteLine("PDF Document Created");
}

public class WordDocument : IDocument
{
    public void Create() => System.Console.WriteLine("Word Document Created");
}

public class DocumentFactory
{
    public static IDocument CreateDocument(string type)
    {
        return type switch
        {
            "PDF" => new PdfDocument(),
            "WORD" => new WordDocument(),
            _ => null
        };
    }
}