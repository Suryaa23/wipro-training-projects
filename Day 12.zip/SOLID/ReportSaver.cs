// Responsible only for saving reports (SRP)
public class ReportSaver
{
    public void Save(string content)
    {
        System.Console.WriteLine("Report Saved: " + content);
    }
}