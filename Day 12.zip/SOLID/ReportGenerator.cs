// Responsible only for generating reports (SRP)
public class ReportGenerator
{
    public string GenerateReport()
    {
        return "Report Content";
    }
}