// Interface for Open/Closed Principle (OCP)
public interface IReportFormatter
{
    string Format(string content);
}