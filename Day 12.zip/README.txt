Wipro NGA .NET Coding Assignment

Contents:
1. SOLID Principles Example
2. Design Patterns Example (Singleton, Factory, Observer)

This is a basic submission-ready template structure.
