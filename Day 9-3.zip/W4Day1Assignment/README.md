# Wipro NGA .NET Daily Coding Assignment (W4 Day 1)

This solution implements the requirements from the assignment PDF:

## Assignment 1: Middleware + Static Files + Basic Security
- Request/response logging middleware (`RequestResponseLoggingMiddleware`)
- Custom error page for unhandled exceptions (`/Error`)
- Static files served from `wwwroot` (HTML/CSS/JS)
- HTTPS enforced (`UseHttpsRedirection`)
- Content Security Policy + basic security headers (`SecurityHeadersMiddleware`)

## Assignment 2: Razor Pages + PageModels + Dynamic Data
- Razor Pages configured with proper folder structure (`Pages`)
- Items list page: `Pages/Items/Index` (foreach loop)
- Add item page: `Pages/Items/Create` (form POST + property binding)
- Dynamic updates: `InMemoryItemRepository` (singleton) updates list after add

## How to run
```bash
cd WiproNGA.Web
dotnet restore
dotnet run
```

Then open:
- Home: https://localhost:5001/
- Razor items list: https://localhost:5001/Items
- Add item: https://localhost:5001/Items/Create
- Static HTML: https://localhost:5001/index.html

> Note: In-memory data resets on restart.
