using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using WiproNGA.Web.Services;
using WiproNGA.Web.Middleware;

namespace WiproNGA.Web;

public class Startup
{
    public void ConfigureServices(IServiceCollection services)
    {
        services.AddRazorPages();

        // Simple in-memory repository so the list updates dynamically after adds.
        services.AddSingleton<IItemRepository, InMemoryItemRepository>();
    }

    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {
        // Custom error page for unhandled exceptions (User Story 2)
        if (env.IsDevelopment())
        {
            app.UseDeveloperExceptionPage();
        }
        else
        {
            app.UseExceptionHandler("/Error");
            app.UseHsts();
        }

        // Enforce HTTPS (User Story 4)
        app.UseHttpsRedirection();

        // Logging middleware (User Story 1 & 2)
        app.UseMiddleware<RequestResponseLoggingMiddleware>();

        // Content Security Policy headers to mitigate XSS (User Story 4)
        app.UseMiddleware<SecurityHeadersMiddleware>();

        // Serve static files from wwwroot (User Story 3)
        app.UseStaticFiles();

        app.UseRouting();

        app.UseAuthorization();

        app.UseEndpoints(endpoints =>
        {
            endpoints.MapRazorPages();
        });
    }
}
