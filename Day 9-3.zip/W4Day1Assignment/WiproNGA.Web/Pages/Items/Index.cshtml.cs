using Microsoft.AspNetCore.Mvc.RazorPages;
using WiproNGA.Web.Models;
using WiproNGA.Web.Services;

namespace WiproNGA.Web.Pages.Items;

public class IndexModel : PageModel
{
    private readonly IItemRepository _repo;

    public IndexModel(IItemRepository repo) => _repo = repo;

    public IReadOnlyList<Item> Items { get; private set; } = new List<Item>();

    public void OnGet()
    {
        Items = _repo.GetAll();
    }
}
