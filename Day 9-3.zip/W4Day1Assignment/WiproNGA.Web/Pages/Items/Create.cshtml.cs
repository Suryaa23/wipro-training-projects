using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WiproNGA.Web.Services;

namespace WiproNGA.Web.Pages.Items;

public class CreateModel : PageModel
{
    private readonly IItemRepository _repo;

    public CreateModel(IItemRepository repo) => _repo = repo;

    [BindProperty]
    public string Name { get; set; } = string.Empty;

    public string? Message { get; private set; }

    public void OnGet()
    {
    }

    public IActionResult OnPost()
    {
        if (string.IsNullOrWhiteSpace(Name))
        {
            ModelState.AddModelError(nameof(Name), "Item name is required.");
            return Page();
        }

        _repo.Add(Name);
        Message = "Item added! Redirecting to the list...";
        return RedirectToPage("/Items/Index");
    }
}
