using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WiproNGA.Web.Pages;

public class IndexModel : PageModel
{
    public void OnGet()
    {
    }
}
