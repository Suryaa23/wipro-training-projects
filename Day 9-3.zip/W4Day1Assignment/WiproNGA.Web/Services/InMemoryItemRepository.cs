using WiproNGA.Web.Models;

namespace WiproNGA.Web.Services;

/// <summary>
/// Simple in-memory storage for demo purposes (resets when app restarts).
/// </summary>
public sealed class InMemoryItemRepository : IItemRepository
{
    private readonly List<Item> _items = new();
    private int _nextId = 1;
    private readonly object _lock = new();

    public InMemoryItemRepository()
    {
        // Seed some items so the list page shows data immediately.
        Add("Milk");
        Add("Bread");
        Add("Notebook");
    }

    public IReadOnlyList<Item> GetAll()
    {
        lock (_lock)
        {
            return _items
                .OrderByDescending(i => i.CreatedAtUtc)
                .ToList();
        }
    }

    public void Add(string name)
    {
        if (string.IsNullOrWhiteSpace(name))
            return;

        lock (_lock)
        {
            _items.Add(new Item
            {
                Id = _nextId++,
                Name = name.Trim(),
                CreatedAtUtc = DateTime.UtcNow
            });
        }
    }
}
