using WiproNGA.Web.Models;

namespace WiproNGA.Web.Services;

public interface IItemRepository
{
    IReadOnlyList<Item> GetAll();
    void Add(string name);
}
