using System.Diagnostics;

namespace WiproNGA.Web.Middleware;

/// <summary>
/// Logs incoming requests (method, path) and outgoing responses (status code + elapsed ms).
/// </summary>
public sealed class RequestResponseLoggingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<RequestResponseLoggingMiddleware> _logger;

    public RequestResponseLoggingMiddleware(RequestDelegate next, ILogger<RequestResponseLoggingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var sw = Stopwatch.StartNew();

        _logger.LogInformation("Incoming Request: {Method} {Path}", context.Request.Method, context.Request.Path);

        try
        {
            await _next(context);
        }
        finally
        {
            sw.Stop();
            _logger.LogInformation("Outgoing Response: {StatusCode} in {ElapsedMs}ms", context.Response.StatusCode, sw.ElapsedMilliseconds);
        }
    }
}
