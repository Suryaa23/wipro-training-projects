namespace WiproNGA.Web.Middleware;

/// <summary>
/// Adds basic security headers, including a Content-Security-Policy (CSP) to mitigate XSS.
/// (This is a baseline policy suitable for demo apps; adjust as needed for production.)
/// </summary>
public sealed class SecurityHeadersMiddleware
{
    private readonly RequestDelegate _next;

    public SecurityHeadersMiddleware(RequestDelegate next) => _next = next;

    public async Task InvokeAsync(HttpContext context)
    {
        // Basic hardening headers
        context.Response.Headers["X-Content-Type-Options"] = "nosniff";
        context.Response.Headers["X-Frame-Options"] = "DENY";
        context.Response.Headers["Referrer-Policy"] = "no-referrer";
        context.Response.Headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()";

        // CSP: allow self for scripts/styles; allow inline style for simple demo (Bootstrap-free).
        // For stricter CSP, avoid 'unsafe-inline' and use hashes/nonces.
        context.Response.Headers["Content-Security-Policy"] =
            "default-src 'self'; " +
            "script-src 'self'; " +
            "style-src 'self' 'unsafe-inline'; " +
            "img-src 'self' data:; " +
            "object-src 'none'; " +
            "base-uri 'self'; " +
            "frame-ancestors 'none'";

        await _next(context);
    }
}
