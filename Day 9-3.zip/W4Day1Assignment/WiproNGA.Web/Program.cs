using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;

namespace WiproNGA.Web;

public class Program
{
    public static void Main(string[] args)
    {
        CreateHostBuilder(args).Build().Run();
    }

    // Using Startup.cs as requested in the assignment sheet.
    public static IHostBuilder CreateHostBuilder(string[] args) =>
        Host.CreateDefaultBuilder(args)
            .ConfigureWebHostDefaults(webBuilder =>
            {
                webBuilder.UseStartup<Startup>();
            });
}
