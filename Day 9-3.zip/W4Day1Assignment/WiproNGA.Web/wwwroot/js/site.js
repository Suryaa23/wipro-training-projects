// Simple JS to demonstrate serving static JavaScript
document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("helloBtn");
  const out = document.getElementById("helloOut");
  if (btn && out) {
    btn.addEventListener("click", () => {
      out.textContent = "Hello from site.js ✅ (static file served successfully)";
    });
  }
});
