# WK_2_D_1 - Contact Manager (TypeScript)

## Overview
A basic Contact Manager application built with TypeScript as part of Week 2, Day 1 assignment.

## Features
- Add new contacts
- View all contacts
- Modify existing contacts
- Delete contacts
- Error handling for invalid operations

## Files
- `contact.ts` - Contact interface definition
- `contactManager.ts` - ContactManager class with all methods
- `index.ts` - Test script demonstrating all features

## How to Run
```bash
npm install
npm run build
npm start
```

Or using ts-node directly:
```bash
npm install
npx ts-node index.ts
```
