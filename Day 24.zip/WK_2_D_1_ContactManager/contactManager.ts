import { Contact } from "./contact";

export class ContactManager {
  private contacts: Contact[] = [];

  // Add a new contact
  addContact(contact: Contact): void {
    const existing = this.contacts.find((c) => c.id === contact.id);
    if (existing) {
      console.log(`Error: Contact with ID ${contact.id} already exists.`);
      return;
    }
    this.contacts.push(contact);
    console.log(`Success: Contact "${contact.name}" has been added successfully.`);
  }

  // View all contacts
  viewContacts(): Contact[] {
    if (this.contacts.length === 0) {
      console.log("Info: No contacts found.");
    } else {
      console.log("\n--- Contact List ---");
      this.contacts.forEach((c) => {
        console.log(`ID: ${c.id} | Name: ${c.name} | Email: ${c.email} | Phone: ${c.phone}`);
      });
      console.log("--------------------\n");
    }
    return this.contacts;
  }

  // Modify an existing contact
  modifyContact(id: number, updatedContact: Partial<Contact>): void {
    const index = this.contacts.findIndex((c) => c.id === id);
    if (index === -1) {
      console.log(`Error: Contact with ID ${id} does not exist.`);
      return;
    }
    this.contacts[index] = { ...this.contacts[index], ...updatedContact };
    console.log(`Success: Contact with ID ${id} has been modified successfully.`);
  }

  // Delete a contact
  deleteContact(id: number): void {
    const index = this.contacts.findIndex((c) => c.id === id);
    if (index === -1) {
      console.log(`Error: Contact with ID ${id} does not exist.`);
      return;
    }
    const removed = this.contacts.splice(index, 1)[0];
    console.log(`Success: Contact "${removed.name}" has been deleted successfully.`);
  }
}
