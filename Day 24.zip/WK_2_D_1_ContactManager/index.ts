import { ContactManager } from "./contactManager";
import { Contact } from "./contact";

const manager = new ContactManager();

console.log("========== Contact Manager - Test Script ==========\n");

// 1. Add contacts
console.log(">> Adding Contacts:");
manager.addContact({ id: 1, name: "Alice Johnson", email: "alice@example.com", phone: "9876543210" });
manager.addContact({ id: 2, name: "Bob Smith", email: "bob@example.com", phone: "9123456780" });
manager.addContact({ id: 3, name: "Charlie Brown", email: "charlie@example.com", phone: "9000011111" });

// 2. Try adding duplicate
console.log("\n>> Adding Duplicate Contact (ID 1):");
manager.addContact({ id: 1, name: "Duplicate Alice", email: "dup@example.com", phone: "0000000000" });

// 3. View all contacts
console.log("\n>> Viewing All Contacts:");
manager.viewContacts();

// 4. Modify a contact
console.log(">> Modifying Contact ID 2:");
manager.modifyContact(2, { email: "bob.updated@example.com", phone: "9999988888" });

// 5. Try modifying non-existent contact
console.log("\n>> Modifying Non-Existent Contact ID 99:");
manager.modifyContact(99, { name: "Ghost" });

// 6. View contacts after modification
console.log("\n>> Viewing Contacts After Modification:");
manager.viewContacts();

// 7. Delete a contact
console.log(">> Deleting Contact ID 3:");
manager.deleteContact(3);

// 8. Try deleting non-existent contact
console.log("\n>> Deleting Non-Existent Contact ID 99:");
manager.deleteContact(99);

// 9. View final contacts list
console.log("\n>> Final Contact List:");
manager.viewContacts();

console.log("========== Test Complete ==========");
