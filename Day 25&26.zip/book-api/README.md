# Book Management REST API

A RESTful API built with Node.js and Express.js to manage a list of books stored in a JSON file.

## Setup Instructions

### 1. Install Dependencies
```bash
npm install
```

### 2. Start the Server
```bash
npm start
```
The server runs on **http://localhost:3000**

---

## API Endpoints

### Root
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | Welcome message |

### Books
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/books` | Get all books |
| GET | `/books/:id` | Get a book by ID |
| POST | `/books` | Add a new book |
| PUT | `/books/:id` | Update a book by ID |
| DELETE | `/books/:id` | Delete a book by ID |

---

## Request & Response Examples

### POST /books
**Request Body:**
```json
{
  "title": "The Alchemist",
  "author": "Paulo Coelho"
}
```
**Response:**
```json
{
  "message": "Book added successfully.",
  "book": { "id": 1, "title": "The Alchemist", "author": "Paulo Coelho" }
}
```

### PUT /books/:id
**Request Body:**
```json
{
  "title": "Updated Title"
}
```

### DELETE /books/:id
**Response:**
```json
{
  "message": "Book with ID 1 deleted successfully."
}
```

---

## Features
- Express.js server on port 3000
- Data persistence using `fs` module (data/books.json)
- Async/Await for all file operations
- EventEmitter logging for Add, Update, Delete operations
- Full error handling with try/catch
- ES6+ syntax throughout

## Folder Structure
```
book-api/
├── data/
│   └── books.json
├── services/
│   └── bookService.js
├── server.js
├── package.json
├── package-lock.json
└── README.md
```
