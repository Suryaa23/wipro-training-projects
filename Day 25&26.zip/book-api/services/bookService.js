const fs = require("fs").promises;
const path = require("path");
const { EventEmitter } = require("events");

const DATA_FILE = path.join(__dirname, "../data/books.json");

// EventEmitter for logging book operations
const bookEmitter = new EventEmitter();

bookEmitter.on("Book Added", (book) => {
  console.log(`[EVENT] Book Added: "${book.title}" by ${book.author} (ID: ${book.id})`);
});

bookEmitter.on("Book Updated", (book) => {
  console.log(`[EVENT] Book Updated: ID ${book.id} - "${book.title}"`);
});

bookEmitter.on("Book Deleted", (id) => {
  console.log(`[EVENT] Book Deleted: ID ${id}`);
});

// Read all books from JSON file
const readBooks = async () => {
  try {
    const data = await fs.readFile(DATA_FILE, "utf-8");
    return JSON.parse(data);
  } catch (error) {
    throw new Error("Failed to read books data: " + error.message);
  }
};

// Write books array to JSON file
const writeBooks = async (books) => {
  try {
    await fs.writeFile(DATA_FILE, JSON.stringify(books, null, 2), "utf-8");
  } catch (error) {
    throw new Error("Failed to write books data: " + error.message);
  }
};

// Get all books
const getAllBooks = async () => {
  return await readBooks();
};

// Get book by ID
const getBookById = async (id) => {
  const books = await readBooks();
  return books.find((b) => b.id === id) || null;
};

// Add a new book
const addBook = async (title, author) => {
  const books = await readBooks();
  const newBook = {
    id: books.length > 0 ? Math.max(...books.map((b) => b.id)) + 1 : 1,
    title,
    author,
  };
  books.push(newBook);
  await writeBooks(books);
  bookEmitter.emit("Book Added", newBook);
  return newBook;
};

// Update a book by ID
const updateBook = async (id, updatedData) => {
  const books = await readBooks();
  const index = books.findIndex((b) => b.id === id);
  if (index === -1) return null;
  books[index] = { ...books[index], ...updatedData, id };
  await writeBooks(books);
  bookEmitter.emit("Book Updated", books[index]);
  return books[index];
};

// Delete a book by ID
const deleteBook = async (id) => {
  const books = await readBooks();
  const index = books.findIndex((b) => b.id === id);
  if (index === -1) return false;
  books.splice(index, 1);
  await writeBooks(books);
  bookEmitter.emit("Book Deleted", id);
  return true;
};

module.exports = { getAllBooks, getBookById, addBook, updateBook, deleteBook };
