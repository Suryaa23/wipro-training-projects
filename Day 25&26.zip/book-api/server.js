const express = require("express");
const {
  getAllBooks,
  getBookById,
  addBook,
  updateBook,
  deleteBook,
} = require("./services/bookService");

const app = express();
const PORT = 3000;

app.use(express.json());

// Root route
app.get("/", (req, res) => {
  res.json({ message: "Welcome to Book Management API" });
});

// GET /books - Returns all books
app.get("/books", async (req, res) => {
  try {
    const books = await getAllBooks();
    res.json(books);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /books/:id - Returns a book by ID
app.get("/books/:id", async (req, res) => {
  try {
    const book = await getBookById(parseInt(req.params.id));
    if (!book) {
      return res.status(404).json({ error: `Book with ID ${req.params.id} not found.` });
    }
    res.json(book);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /books - Adds a new book
app.post("/books", async (req, res) => {
  try {
    const { title, author } = req.body;
    if (!title || !author) {
      return res.status(400).json({ error: "Both 'title' and 'author' are required." });
    }
    const newBook = await addBook(title, author);
    res.status(201).json({ message: "Book added successfully.", book: newBook });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// PUT /books/:id - Updates a book by ID
app.put("/books/:id", async (req, res) => {
  try {
    const updatedBook = await updateBook(parseInt(req.params.id), req.body);
    if (!updatedBook) {
      return res.status(404).json({ error: `Book with ID ${req.params.id} not found.` });
    }
    res.json({ message: "Book updated successfully.", book: updatedBook });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// DELETE /books/:id - Deletes a book by ID
app.delete("/books/:id", async (req, res) => {
  try {
    const deleted = await deleteBook(parseInt(req.params.id));
    if (!deleted) {
      return res.status(404).json({ error: `Book with ID ${req.params.id} not found.` });
    }
    res.json({ message: `Book with ID ${req.params.id} deleted successfully.` });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
