# RESTful API – Online Book Store (ASP.NET Core)

This submission implements the RESTful API required in **Problem_Statement_42.pdf**.

## Tech
- ASP.NET Core Web API (Controllers + Attribute Routing)
- EF Core + SQLite (local DB file: `bookstore.db`)
- Swagger UI for quick testing

## How to Run (Visual Studio 2022)
1. Open `BookStoreApi.sln`
2. Restore NuGet packages
3. Run the project
4. Open Swagger: `/swagger`

> On first run, the API auto-creates the SQLite database and seeds sample data.

## Base URL
- https://localhost:7162 (HTTPS) or http://localhost:5162 (HTTP)

## Endpoints

### Books
- `GET    /api/books`
- `GET    /api/books/{id}`
- `POST   /api/books`
- `PUT    /api/books/{id}`
- `DELETE /api/books/{id}`

### Authors
- `GET    /api/authors`
- `GET    /api/authors/{id}`
- `POST   /api/authors`
- `PUT    /api/authors/{id}`
- `DELETE /api/authors/{id}`

### Association
- `GET /api/authors/{authorId}/books`

## Postman Sample Bodies

### Create Author (POST /api/authors)
```json
{
  "name": "Chetan Bhagat",
  "country": "India"
}
```

### Create Book (POST /api/books)
```json
{
  "title": "Five Point Someone",
  "publicationYear": 2004,
  "authorId": 1
}
```

### Update Book (PUT /api/books/1)
```json
{
  "title": "Malgudi Days (Updated)",
  "publicationYear": 1943,
  "authorId": 2
}
```

## Expected Status Codes
- 200 OK (GET)
- 201 Created (POST)
- 204 No Content (PUT, DELETE success)
- 400 Bad Request (validation errors)
- 404 Not Found (missing book/author)

## Fiddler
Use Fiddler to inspect request/response headers and verify `Content-Type: application/json`.
