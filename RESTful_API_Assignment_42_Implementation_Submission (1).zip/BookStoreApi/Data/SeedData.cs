using BookStoreApi.Models;

namespace BookStoreApi.Data;

public static class SeedData
{
    public static void Initialize(AppDbContext db)
    {
        if (db.Authors.Any() || db.Books.Any())
            return;

        var authors = new List<Author>
        {
            new() { Name = "J. K. Rowling", Country = "UK" },
            new() { Name = "R. K. Narayan", Country = "India" }
        };

        db.Authors.AddRange(authors);
        db.SaveChanges();

        var books = new List<Book>
        {
            new() { Title = "Harry Potter and the Philosopher's Stone", PublicationYear = 1997, AuthorId = authors[0].Id },
            new() { Title = "Harry Potter and the Chamber of Secrets", PublicationYear = 1998, AuthorId = authors[0].Id },
            new() { Title = "Malgudi Days", PublicationYear = 1943, AuthorId = authors[1].Id }
        };

        db.Books.AddRange(books);
        db.SaveChanges();
    }
}
