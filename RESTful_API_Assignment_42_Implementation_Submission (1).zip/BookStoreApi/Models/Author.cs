using System.ComponentModel.DataAnnotations;

namespace BookStoreApi.Models;

public class Author
{
    public int Id { get; set; }

    [Required]
    [MaxLength(120)]
    public string Name { get; set; } = string.Empty;

    [MaxLength(80)]
    public string? Country { get; set; }

    public List<Book> Books { get; set; } = new();
}
