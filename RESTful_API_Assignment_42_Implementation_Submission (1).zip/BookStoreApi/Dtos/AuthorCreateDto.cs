using System.ComponentModel.DataAnnotations;

namespace BookStoreApi.Dtos;

public class AuthorCreateDto
{
    [Required]
    [MaxLength(120)]
    public string Name { get; set; } = string.Empty;

    [MaxLength(80)]
    public string? Country { get; set; }
}
