using System.ComponentModel.DataAnnotations;

namespace BookStoreApi.Dtos;

public class BookCreateDto
{
    [Required]
    [MaxLength(200)]
    public string Title { get; set; } = string.Empty;

    [Range(1450, 2100)]
    public int PublicationYear { get; set; }

    [Required]
    public int AuthorId { get; set; }
}
