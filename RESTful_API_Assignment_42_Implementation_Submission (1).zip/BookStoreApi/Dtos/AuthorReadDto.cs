namespace BookStoreApi.Dtos;

public class AuthorReadDto
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Country { get; set; }
}
