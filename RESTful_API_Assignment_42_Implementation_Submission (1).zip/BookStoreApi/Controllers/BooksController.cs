using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BookStoreApi.Data;
using BookStoreApi.Dtos;
using BookStoreApi.Models;

namespace BookStoreApi.Controllers;

[ApiController]
[Route("api/books")]
public class BooksController : ControllerBase
{
    private readonly AppDbContext _db;
    public BooksController(AppDbContext db) => _db = db;

    // GET: api/books
    [HttpGet]
    public async Task<ActionResult<IEnumerable<BookReadDto>>> GetAll()
    {
        var items = await _db.Books
            .AsNoTracking()
            .Include(b => b.Author)
            .OrderBy(b => b.Id)
            .Select(b => new BookReadDto
            {
                Id = b.Id,
                Title = b.Title,
                PublicationYear = b.PublicationYear,
                AuthorId = b.AuthorId,
                AuthorName = b.Author!.Name
            })
            .ToListAsync();

        return Ok(items);
    }

    // GET: api/books/{id}
    [HttpGet("{id:int}")]
    public async Task<ActionResult<BookReadDto>> GetById(int id)
    {
        var b = await _db.Books
            .AsNoTracking()
            .Include(x => x.Author)
            .FirstOrDefaultAsync(x => x.Id == id);

        if (b is null) return NotFound(new { message = $"Book with id={id} not found." });

        return Ok(new BookReadDto
        {
            Id = b.Id,
            Title = b.Title,
            PublicationYear = b.PublicationYear,
            AuthorId = b.AuthorId,
            AuthorName = b.Author!.Name
        });
    }

    // POST: api/books
    [HttpPost]
    public async Task<ActionResult<BookReadDto>> Create(BookCreateDto dto)
    {
        var author = await _db.Authors.FindAsync(dto.AuthorId);
        if (author is null)
            return NotFound(new { message = $"Author with id={dto.AuthorId} not found." });

        var entity = new Book
        {
            Title = dto.Title.Trim(),
            PublicationYear = dto.PublicationYear,
            AuthorId = dto.AuthorId
        };

        _db.Books.Add(entity);
        await _db.SaveChangesAsync();

        var read = new BookReadDto
        {
            Id = entity.Id,
            Title = entity.Title,
            PublicationYear = entity.PublicationYear,
            AuthorId = entity.AuthorId,
            AuthorName = author.Name
        };

        return CreatedAtAction(nameof(GetById), new { id = entity.Id }, read);
    }

    // PUT: api/books/{id}
    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, BookUpdateDto dto)
    {
        var entity = await _db.Books.FindAsync(id);
        if (entity is null) return NotFound(new { message = $"Book with id={id} not found." });

        var author = await _db.Authors.FindAsync(dto.AuthorId);
        if (author is null)
            return NotFound(new { message = $"Author with id={dto.AuthorId} not found." });

        entity.Title = dto.Title.Trim();
        entity.PublicationYear = dto.PublicationYear;
        entity.AuthorId = dto.AuthorId;

        await _db.SaveChangesAsync();
        return NoContent(); // 204
    }

    // DELETE: api/books/{id}
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var entity = await _db.Books.FindAsync(id);
        if (entity is null) return NotFound(new { message = $"Book with id={id} not found." });

        _db.Books.Remove(entity);
        await _db.SaveChangesAsync();
        return NoContent(); // 204
    }
}
