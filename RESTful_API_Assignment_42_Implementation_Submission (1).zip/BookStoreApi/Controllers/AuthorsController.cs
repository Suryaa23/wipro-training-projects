using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BookStoreApi.Data;
using BookStoreApi.Dtos;
using BookStoreApi.Models;

namespace BookStoreApi.Controllers;

[ApiController]
[Route("api/authors")]
public class AuthorsController : ControllerBase
{
    private readonly AppDbContext _db;
    public AuthorsController(AppDbContext db) => _db = db;

    // GET: api/authors
    [HttpGet]
    public async Task<ActionResult<IEnumerable<AuthorReadDto>>> GetAll()
    {
        var items = await _db.Authors
            .AsNoTracking()
            .OrderBy(a => a.Id)
            .Select(a => new AuthorReadDto { Id = a.Id, Name = a.Name, Country = a.Country })
            .ToListAsync();

        return Ok(items);
    }

    // GET: api/authors/{id}
    [HttpGet("{id:int}")]
    public async Task<ActionResult<AuthorReadDto>> GetById(int id)
    {
        var a = await _db.Authors.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        if (a is null) return NotFound(new { message = $"Author with id={id} not found." });

        return Ok(new AuthorReadDto { Id = a.Id, Name = a.Name, Country = a.Country });
    }

    // POST: api/authors
    [HttpPost]
    public async Task<ActionResult<AuthorReadDto>> Create(AuthorCreateDto dto)
    {
        var entity = new Author { Name = dto.Name.Trim(), Country = dto.Country?.Trim() };
        _db.Authors.Add(entity);
        await _db.SaveChangesAsync();

        var read = new AuthorReadDto { Id = entity.Id, Name = entity.Name, Country = entity.Country };
        return CreatedAtAction(nameof(GetById), new { id = entity.Id }, read);
    }

    // PUT: api/authors/{id}
    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, AuthorCreateDto dto)
    {
        var entity = await _db.Authors.FindAsync(id);
        if (entity is null) return NotFound(new { message = $"Author with id={id} not found." });

        entity.Name = dto.Name.Trim();
        entity.Country = dto.Country?.Trim();

        await _db.SaveChangesAsync();
        return NoContent();
    }

    // DELETE: api/authors/{id}
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var entity = await _db.Authors.FindAsync(id);
        if (entity is null) return NotFound(new { message = $"Author with id={id} not found." });

        _db.Authors.Remove(entity);
        await _db.SaveChangesAsync();
        return NoContent();
    }

    // GET: api/authors/{authorId}/books
    [HttpGet("{authorId:int}/books")]
    public async Task<ActionResult<IEnumerable<BookReadDto>>> GetBooksByAuthor(int authorId)
    {
        var exists = await _db.Authors.AsNoTracking().AnyAsync(a => a.Id == authorId);
        if (!exists) return NotFound(new { message = $"Author with id={authorId} not found." });

        var books = await _db.Books
            .AsNoTracking()
            .Include(b => b.Author)
            .Where(b => b.AuthorId == authorId)
            .OrderBy(b => b.Id)
            .Select(b => new BookReadDto
            {
                Id = b.Id,
                Title = b.Title,
                PublicationYear = b.PublicationYear,
                AuthorId = b.AuthorId,
                AuthorName = b.Author!.Name
            })
            .ToListAsync();

        return Ok(books);
    }
}
